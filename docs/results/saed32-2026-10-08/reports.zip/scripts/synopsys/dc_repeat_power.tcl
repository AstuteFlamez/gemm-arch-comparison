# Reload one frozen mapped design; only workload activity changes.
proc require_success {label script} {
    set result [uplevel 1 $script]
    if {$result ne "1"} {error "$label returned $result"}
}
proc repeat_power {} {
    source run_config.tcl
    set_host_options -max_cores 1
    set_app_var target_library [list $target_db]
    set_app_var link_library [list * $target_db]
    read_ddc mapped.ddc
    require_success link {link}
    if {[get_object_name [current_design]] ne "${top}_MatrixDim${matrix_dim}"} {
        error "Reloaded the wrong design"
    }
    require_success mapped_check {check_design}
    if {[sizeof_collection [get_cells -hierarchical -filter "is_unmapped == true"]] != 0} {
        error "Unmapped cells in frozen design"
    }
    redirect library.rpt {require_success report_lib {report_lib $library_name}}
    redirect units.rpt {report_units}
    redirect area.rpt {report_area -hierarchy}
    redirect timing.rpt {report_timing -delay_type max -max_paths 10}
    redirect constraints.rpt {report_constraint -all_violators}
    redirect timing_checks.rpt {check_timing}
    redirect qor.rpt {report_qor}
    redirect references.rpt {report_reference -hierarchy}
    redirect design.rpt {report_design}
    write_sdc mapped.sdc
    require_success read_saif {
        read_saif -auto_map_names -input ../sim/activity.saif -instance_name tb_gemm_ppa/dut
    }
    redirect activity.rpt {report_saif -hierarchy -rtl_saif}
    redirect activity_missing.rpt {report_saif -hierarchy -rtl_saif -missing}
    redirect power.rpt {require_success report_power {report_power -analysis_effort high -verbose}}
    redirect power_hierarchy.rpt {report_power -hierarchy}
    set marker [open reports.complete w]
    puts $marker "Frozen mapped DDC reloaded; review coverage and replay equivalence before use."
    close $marker
}
if {[catch {repeat_power} failure]} {
    puts stderr "FAIL PPA: $failure"
    exit 1
}
exit 0
