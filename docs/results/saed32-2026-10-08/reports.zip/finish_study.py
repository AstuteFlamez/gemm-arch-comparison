from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,re,signal,subprocess,time,zipfile
root=Path('.').resolve(); controller=127143; baseline=root/'build/seed-20261008'
assert b'run_study.py' in Path('/proc/'+str(controller)+'/cmdline').read_bytes().split(b'\0')
assert 'T (stopped)' in Path('/proc/'+str(controller)+'/status').read_text()
def now(): return datetime.now(timezone.utc).isoformat()
def save(state):
 p=root/'study.json.tmp'; p.write_text(json.dumps(state,indent=2)+'\n'); p.replace(root/'study.json')
def command(argv,logname):
 print('START',logname,now(),flush=True)
 with (root/logname).open('w') as log: result=subprocess.run(argv,cwd=root,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT)
 print('END',logname,result.returncode,now(),flush=True); return result.returncode
while True:
 m=json.loads((baseline/'run.json').read_text())
 if m['status']!='running': break
 time.sleep(5)
if m['status']!='reports_need_review':
 os.kill(controller,signal.SIGCONT); raise RuntimeError('Baseline failed; original controller resumed to record failure.')
while Path('/proc/127231/status').exists():
 if 'Z (zombie)' in Path('/proc/127231/status').read_text(): break
 time.sleep(1)
os.kill(controller,signal.SIGTERM)
try: os.kill(controller,signal.SIGCONT)
except ProcessLookupError: pass
state=json.loads((root/'study.json').read_text()); state['runs'][0].update(status='reports_need_review',finished_utc=now(),returncode=0); state['status']='verifying_frozen_design_replay'; save(state)
prefix='synopsys-run env SYNOPSYS_LC_ROOT=/srv/auto/apps/synopsys-2026/lc/Y-2026.03'
replay=['python3','scripts/repeat_gemm_power.py','--baseline',str(baseline),'--tool-prefix',prefix]
try:
 verified=command(replay+['--verify-replay','--out',str(root/'build/replay-check')],'replay-check.log')==0
 state['replay_verified']=verified; state['synthesis_plan']='six fresh syntheses, then frozen-DDC power repeats' if verified else 'full synthesis for every seed (replay check failed)'; save(state)
 for seed in (20261009,20261010):
  record={'seed':seed,'status':'running','started_utc':now()}; state['runs'].append(record); state['status']='running'; save(state)
  out=root/'build'/('seed-'+str(seed))
  if verified: argv=replay+['--seed',str(seed),'--out',str(out)]
  else: argv=['python3','scripts/run_gemm_ppa.py','--flow','ppa','--sizes','8','16','32','--random-count','100','--seed',str(seed),'--config','scripts/synopsys/config.saed32.json','--tool-prefix',prefix,'--out',str(out)]
  rc=command(argv,'seed-'+str(seed)+'.log'); record.update(returncode=rc,finished_utc=now(),status='reports_need_review' if rc==0 else 'failed'); save(state)
  if rc: raise RuntimeError('Seed '+str(seed)+' failed')
 state['status']='reviewing_high_fanout'; save(state)
 rc=command(['synopsys-run','env','SYNOPSYS_LC_ROOT=/srv/auto/apps/synopsys-2026/lc/Y-2026.03','dc_shell','-f','review_high_fanout.tcl'],'review-high-fanout.log')
 require_log=(root/'review-high-fanout.log').read_text()
 if rc or re.search(r'(?m)^\s*(Error[:\-]|Fatal:)',require_log): raise RuntimeError('High-fanout review failed')
 state['status']='reports_need_review'; state['finished_utc']=now(); save(state)
 archive=root/'review-export/study-reports.zip'
 if archive.exists(): archive.rename(root/'review-export/study-partial-before-final.zip')
 rc=command(['python3','scripts/export_gemm_ppa.py',*[str(root/'build'/('seed-'+str(seed))) for seed in (20261008,20261009,20261010)],'--out',str(archive)],'export-final.log')
 if rc: raise RuntimeError('Final export failed')
 extras=[root/name for name in ('study.json','snapshot-sha256.json','run_study.py','finish_study.py','replay-check.log','review-high-fanout.log','review_high_fanout.tcl')]
 extras.extend(root/name for name in json.loads((root/'snapshot-sha256.json').read_text()))
 extras.extend(root/name for name in ('scripts/repeat_gemm_power.py','scripts/synopsys/dc_repeat_power.tcl','scripts/export_gemm_ppa.py'))
 if verified:
  extras.append(baseline/'power-replay-verified.json'); extras.append(root/'build/replay-check/run.json')
  extras.extend(p for p in (root/'build/replay-check').glob('*/*/dc/*') if (p.suffix=='.rpt' and p.name!='library.rpt') or p.name in ('dc.log','mapped.sdc','reports.complete'))
 with zipfile.ZipFile(archive,'a',zipfile.ZIP_DEFLATED) as z:
  for p in extras: z.write(p,p.relative_to(root))
 state['report_bundle_sha256']=hashlib.sha256(archive.read_bytes()).hexdigest(); state['report_bundle_bytes']=archive.stat().st_size; state['export_complete']=True; save(state)
 print('STUDY_READY',state['report_bundle_sha256'],flush=True)
except Exception as error:
 state.update(status='failed',error=str(error),finished_utc=now()); save(state); raise
