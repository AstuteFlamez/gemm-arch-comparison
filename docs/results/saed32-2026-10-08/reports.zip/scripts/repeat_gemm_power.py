#!/usr/bin/env python3
"""Repeat VCS activity and power on the exact mapped hardware from a PPA run.

First validate DDC reloads with --verify-replay, which must reproduce the seed's
power and complete annotation. Subsequent seeds retain the same mapped bytes.
No synthesis optimization runs in this flow.
"""
import argparse
from datetime import datetime, timezone
import json
import math
from pathlib import Path
import re
import shlex
import shutil
import sys

import run_gemm_ppa as ppa

ROOT = Path(__file__).resolve().parents[1]
SCRIPT = ROOT / "scripts/synopsys/dc_repeat_power.tcl"


def require(condition, message):
    if not condition:
        raise ValueError(message)


def power_values(path):
    text = path.read_text()
    values = []
    for label in ("Total Dynamic Power", "Cell Leakage Power"):
        match = re.search(re.escape(label) + r"\s*=\s*([\d.eE+-]+)\s*(pW|nW|uW|mW|W)\b", text)
        require(match is not None, f"Missing power unit: {path}/{label}")
        values.append(float(match[1]) * {"pW":1e-9,"nW":1e-6,"uW":1e-3,"mW":1,"W":1000}[match[2]])
    return values


def validate_reload(dc, original, verify):
    ppa.check_dc_reports(dc)
    annotation = (dc / "activity_missing.rpt").read_text()
    for kind in ("ports", "sequential cells", "three-state cells"):
        require(re.search(r"(?m)^\s*0 " + kind + r"\s*$", annotation), f"DDC replay lost activity annotation: {dc}/{kind}")
    require("This design has no violated constraints." in (dc / "constraints.rpt").read_text(), f"Replay constraint violations: {dc}")
    for filename in ("dc.log", "power.rpt", "power_hierarchy.rpt"):
        require(not re.search(r"Warning:.*\(PWR-", (dc / filename).read_text()), f"Replay power warning: {dc}/{filename}")
    for pattern, filename in ((r"Total cell area:\s*([\d.]+)", "area.rpt"),
                              (r"Critical Path Slack:\s*([\d.]+)", "qor.rpt")):
        left = re.search(pattern,(dc/filename).read_text())
        right = re.search(pattern,(original/filename).read_text())
        require(left is not None and right is not None and left[1] == right[1], f"DDC reload changed area/timing: {dc}/{filename}")
    def constraints(path):
        return [line.strip() for line in path.read_text().splitlines() if line.strip() and not line.startswith('#')]
    require(constraints(dc/'mapped.sdc') == constraints(original/'mapped.sdc'), f"DDC reload changed constraints: {dc}")
    if verify:
        for repeated, baseline in zip(power_values(dc/'power.rpt'),power_values(original/'power.rpt')):
            require(math.isclose(repeated,baseline,rel_tol=5e-5,abs_tol=1e-4), f"Same-seed power replay differs: {dc}: {repeated} vs {baseline} mW")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--baseline',required=True,type=Path)
    parser.add_argument('--out',required=True,type=Path)
    parser.add_argument('--seed',type=int)
    parser.add_argument('--verify-replay',action='store_true')
    parser.add_argument('--tool-prefix',default='')
    args = parser.parse_args()
    baseline = args.baseline.resolve()
    original = json.loads((baseline/'run.json').read_text())
    require(original['status']=='reports_need_review' and original['flow']=='ppa','Baseline PPA must be complete')
    require(not original.get('synthesis_mode'), 'Baseline must be a fresh synthesis run')
    require(ppa.digest(Path(original['config']['target_db'])) == original['library_sha256'],'Library changed since synthesis')
    for name,sha in original['source_sha256'].items():
        require(ppa.digest(ROOT/name)==sha,f'Source changed since synthesis: {name}')
    out = args.out.resolve()
    require(not out.exists(),'Output path must be new')
    prefix=shlex.split(args.tool_prefix)
    if args.verify_replay:
        require(args.seed is None or args.seed==original['seed'],'Replay must use the original seed')
        out.mkdir(parents=True)
        meta=json.loads(json.dumps(original))
        meta['commands']=[]
        meta['started_utc']=datetime.now(timezone.utc).isoformat()
        for b in original['benchmarks']:
            dest=out/str(b['matrix_dim'])/b['architecture']/'sim'
            dest.mkdir(parents=True)
            (dest/'activity.saif').symlink_to(baseline/str(b['matrix_dim'])/b['architecture']/'sim/activity.saif')
    else:
        require(args.seed is not None and args.seed!=original['seed'],'Choose a new workload seed')
        marker=json.loads((baseline/'power-replay-verified.json').read_text())
        require(marker['baseline_run_sha256']==ppa.digest(baseline/'run.json') and marker['replay_tcl_sha256']==ppa.digest(SCRIPT),'Replay validation is stale')
        command=[sys.executable,str(ROOT/'scripts/run_gemm_ppa.py'),'--flow','activity','--sizes',*[str(s) for s in original['sizes']],
                 '--random-count',str(original['random_count']),'--seed',str(args.seed),'--clock-ns',str(original['clock_period_ns']),
                 '--tool-prefix',args.tool_prefix,'--out',str(out)]
        ppa.run_command(command,baseline,f"activity-seed-{args.seed}.log",[])
        meta=json.loads((out/'run.json').read_text())
        require(meta['status']=='passed' and meta['source_sha256']==original['source_sha256'],'Activity source mismatch')
        meta['config']=original['config']; meta['library_sha256']=original['library_sha256']
    meta.update(flow='ppa',status='running',synthesis_mode='frozen_ddc_replay',synthesis_baseline=str(baseline),
                baseline_run_sha256=ppa.digest(baseline/'run.json'),replay_tcl_sha256=ppa.digest(SCRIPT),
                replay_driver_sha256=ppa.digest(Path(__file__)),mapped_ddc_sha256={})
    ppa.write_json(out/'run.json',meta)
    try:
        for b in meta['benchmarks']:
            relative=Path(str(b['matrix_dim']))/b['architecture']/'dc'
            source=baseline/relative; dc=out/relative; dc.mkdir(parents=True)
            for filename in ('mapped.ddc','mapped.v','saifmap.primepower.tcl','run_config.tcl'):
                shutil.copy2(source/filename,dc/filename)
            sha=ppa.digest(source/'mapped.ddc')
            require(ppa.digest(dc/'mapped.ddc')==sha,'DDC copy mismatch')
            meta['mapped_ddc_sha256'][str(relative)]=sha
            ppa.run_command(prefix+['dc_shell','-f',str(SCRIPT)],dc,'dc.log',meta['commands'])
            validate_reload(dc,source,args.verify_replay)
            require(ppa.digest(dc/'mapped.ddc')==sha,'Frozen DDC changed during replay')
            ppa.write_json(out/'run.json',meta)
        require(ppa.digest(Path(original['config']['target_db']))==original['library_sha256'],'Library changed during replay')
        meta['status']='replay_verified' if args.verify_replay else 'reports_need_review'
        if args.verify_replay:
            ppa.write_json(baseline/'power-replay-verified.json',{'baseline_run_sha256':ppa.digest(baseline/'run.json'),
                           'replay_tcl_sha256':ppa.digest(SCRIPT),'validation_run':str(out),
                           'verified_utc':datetime.now(timezone.utc).isoformat()})
    except Exception as error:
        meta.update(status='failed',error=str(error))
        raise
    finally:
        meta['finished_utc']=datetime.now(timezone.utc).isoformat()
        ppa.write_json(out/'run.json',meta)
    print(meta['status'],out)


if __name__=='__main__':
    main()
