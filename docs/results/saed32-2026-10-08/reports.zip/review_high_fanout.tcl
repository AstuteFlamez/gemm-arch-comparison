set_host_options -max_cores 1
source build/seed-20261008/8/systolic/dc/run_config.tcl
set_app_var target_library [list $target_db]
set_app_var link_library [list * $target_db]
foreach ppa_size {8 16 32} {
 foreach ppa_arch {systolic conventional} {
  read_ddc build/seed-20261008/$ppa_size/$ppa_arch/dc/mapped.ddc
  puts "REVIEW_DESIGN $ppa_size $ppa_arch [get_object_name [current_design]]"
  foreach_in_collection ppa_high_net [all_high_fanout -nets -threshold 1000] {
   puts "HIGH_FANOUT $ppa_size $ppa_arch [get_object_name $ppa_high_net] [sizeof_collection [all_connected -leaf $ppa_high_net]]"
  }
  remove_design -all
 }
}
exit
