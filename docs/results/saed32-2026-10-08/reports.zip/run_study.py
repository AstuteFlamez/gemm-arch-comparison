from datetime import datetime,timezone
from pathlib import Path
import json,subprocess,sys
root=Path(__file__).resolve().parent
out=root/'build';out.mkdir(exist_ok=True)
status={'started_utc':datetime.now(timezone.utc).isoformat(),'status':'running','sizes':[8,16,32],'seeds':[20261008,20261009,20261010],'random_count':100,'runs':[]}
def save():
 p=root/'study.json';t=root/'study.json.tmp';t.write_text(json.dumps(status,indent=2)+'\n');t.replace(p)
save()
try:
 for seed in status['seeds']:
  record={'seed':seed,'status':'running','started_utc':datetime.now(timezone.utc).isoformat()};status['runs'].append(record);save()
  command=[sys.executable,'-u','scripts/run_gemm_ppa.py','--flow','ppa','--sizes','8','16','32','--random-count','100','--seed',str(seed),'--config','scripts/synopsys/config.saed32.json','--tool-prefix','synopsys-run env SYNOPSYS_LC_ROOT=/srv/auto/apps/synopsys-2026/lc/Y-2026.03','--out',str(out/('seed-'+str(seed)))]
  print('START',seed,flush=True)
  with (root/('seed-'+str(seed)+'.log')).open('w') as log:
   result=subprocess.run(command,cwd=root,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT)
  record['returncode']=result.returncode;record['finished_utc']=datetime.now(timezone.utc).isoformat();record['status']='reports_need_review' if result.returncode==0 else 'failed';save()
  if result.returncode:raise RuntimeError('Seed '+str(seed)+' failed; inspect its log.')
  print('FINISHED',seed,flush=True)
 status['status']='reports_need_review'
except Exception as error:
 status['status']='failed';status['error']=str(error);raise
finally:
 status['finished_utc']=datetime.now(timezone.utc).isoformat();save()
